import 'dart:async';

import 'package:flutter/material.dart';

import '../register.dart';
import '../sign_in.dart';

class MySplashScreen extends StatefulWidget {
  const MySplashScreen({Key? key}) : super(key: key);

  @override
  State<MySplashScreen> createState() => _MySplashScreenState();
}

class _MySplashScreenState extends State<MySplashScreen> {
  startTimer() {
    Timer(const Duration(seconds: 5), () async {
      Navigator.push(context, MaterialPageRoute(builder: (c) => RegisterPage()));
    });
  }

  @override
  void initState() {
    super.initState();
    startTimer();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Stack(
        children: [
          SizedBox(height: 30,),
          Expanded(
            child: Image.network(
              'https://img.freepik.com/vector-premium/ilustracion-concepto-pedido-linea-comida-restaurante-personajes-dibujos-animados-cliente-cafe-jefe-cocina-web-idea-creativa-aplicacion-movil-orden-nutricion-saludable_151150-819.jpg?w=740',
              fit: BoxFit.cover,
              height: 500,
            ),
          ),
          // Container(
          //   color: Colors.black.withOpacity(0.5),
          //   child: const Center(
          //     child: Padding(
          //       padding: EdgeInsets.all(18.0),
          //       child: Text(
          //         "Food On-Line",
          //         textAlign: TextAlign.center,
          //         style: TextStyle(
          //           color: Colors.white,
          //           fontSize: 40,
          //           fontFamily: "Signatra",
          //           letterSpacing: 3,
          //         ),
          //       ),
          //     ),
          //   ),
          // ),
        ],
      ),
    );
  }
}
