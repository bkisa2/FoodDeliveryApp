import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

import 'firebase_utils.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Flutter Firebase Demo'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () async {
            // Sign in with Google
            final UserCredential userCredential = await signInWithGoogle();

            // Save user data to Firestore
            await saveUserData(userCredential.user!);

            // Navigate to the user profile screen
            Navigator.pushReplacementNamed(context, '/profile');
          },
          child: Text('Sign in with Google'),
        ),
      ),
    );
  }
}