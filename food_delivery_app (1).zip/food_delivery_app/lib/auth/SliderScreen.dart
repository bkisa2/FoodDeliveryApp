import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/material.dart';
import '../../car/views/starting_screen.dart';
import '../../pages/home/home.dart';
import '../car/views/schedule_ride/driver register/DriverLoginScreen.dart';
import '../shop/Product/Login/loginShop.dart';

class SliderScreen extends StatefulWidget {
  @override
  _SliderScreenState createState() => _SliderScreenState();
}

class _SliderScreenState extends State<SliderScreen> {
  final List _imagePaths = [    'assets/images/making logo pic.png',    'assets/images/car.png',  ];

  final List _titles = [    'Food Delivery',    'Book a Car',  ];

  final List _descriptions = [    'Order food from your favourite restaurants and we will deliver it to your doorstep.',    'Book a car rental from top providers and get the best deals and discounts.',  ];

  int _current = 0;

  void _navigateToScreen(int index) {
    if (_current == 0) {
      if (index == 0) {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => HomePage()),
        );
      } else if (index == 1) {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ShopLoginScreen()),
        );
      }
    } else if (_current == 1) {
      if (index == 0) {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => StartingPage()),
        );
      } else if (index == 1) {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => DriverLoginScreen()),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: PageView.builder(
              itemCount: _imagePaths.length,
              onPageChanged: (index) {
                setState(() {
                  _current = index;
                });
              },
              itemBuilder: (context, index) {
                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      child: Image.asset(
                        _imagePaths[index],
                        fit: BoxFit.cover,
                        height: 345.0,
                        width: 278.0,
                      ),
                    ),
                    SizedBox(height: 16.0),
                    Text(
                      _titles[index],
                      style: TextStyle(
                        fontSize: 32.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 16.0),
                    Container(
                      margin: const EdgeInsets.only(left: 11, right: 11),
                      child: Text(
                        _descriptions[index],
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16.0,
                        ),
                      ),
                    ),
                    SizedBox(height: 32.0),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          ElevatedButton(
                            onPressed: () => _navigateToScreen(0),
                            child: Text(
                              _current == 0 ? 'Order Food' : 'Book a Car',
                              style: TextStyle(color: Colors.white),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.amber,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(24.0),
                              ),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 48.0, vertical: 16.0),
                            ),
                          ),
                          ElevatedButton(
                            onPressed: () => _navigateToScreen(1),
                            child: Text(
                              _current == 0 ? 'Create Shop' : 'Register Driver',
                              style: TextStyle(color: Colors.white),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.amber,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(24.0),
                              ),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 48.0, vertical: 16.0),
                            ),
                          ),
                        ]
                    ),
                  ],
                );
              },
            ),
          ),
          SizedBox(height: 16.0),
          DotsIndicator(
            dotsCount: _imagePaths.length,
            position: _current.toDouble(),
            decorator: DotsDecorator(
              size: const Size.square(8.0),
              activeSize: const Size(16.0, 8.0),
              activeShape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(5.0),
              ),
            ),
          ),
          SizedBox(height: 32.0),
        ],
      ),
    );
  }
}