import 'package:flutter/material.dart';
import 'package:food_delivery_app/global/global.dart';
import 'package:food_delivery_app/shop/Product/widgets/AddProductScreen.dart';


import '../models/shop.dart';
import 'Product/widgets/ManageOrdersScreen.dart';
import 'Product/widgets/ManageProductsScreen.dart';

class ShopScreen extends StatelessWidget {
  final Shop shop;
  final String shopId;

  const ShopScreen({required this.shop, required this.shopId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(shop.shopName),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Owner: ${shop.ownerName}',
                    style: TextStyle(fontSize: 16.0),
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    'Address: ${shop.address}',
                    style: TextStyle(fontSize: 16.0),
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    'Phone: ${shop.phoneNumber}',
                    style: TextStyle(fontSize: 16.0),
                  ),
                ],
              ),
            ),
            Divider(),
            Padding(
              padding: EdgeInsets.all(16.0),
              child: Text(
                'Products',
                style: TextStyle(fontSize: 20.0),
              ),
            ),
            ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: shop.products?.length,
              itemBuilder: (context, index) {
                final product = shop.products![index];
                return ListTile(
                  leading: Image.network(product.imageUrl),
                  title: Text(product.name),
                  subtitle: Text('\$${product.price.toStringAsFixed(2)}'),
                );
              },
            ),
          ],
        ),
      ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            onPressed: () {
              navigate(context, AddProductScreen(shopId));
            },
            child: Icon(Icons.add),
          ),
          SizedBox(height: 16.0),
          FloatingActionButton(
            onPressed: () {
              navigate(context, ManageProductsScreen(shopId:shopId));
            },
            child: Icon(Icons.edit),
          ),
          SizedBox(height: 16.0),
          FloatingActionButton(
            onPressed: () {
              navigate(context, ManageOrdersScreen());
            },
            child: Icon(Icons.shopping_basket),
          ),
        ],
      ),
    );
  }
}
