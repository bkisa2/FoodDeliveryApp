import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Product {
  final int id;
  final String name;
  final String description;
  final double price;
  final String imageUrl;

  Product({required this.id, required this.name, required this.description, required this.price, required this.imageUrl});

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      price: json['price'],
      imageUrl: json['imageUrl'],
    );

  }

  static fromMap(productData) {}

  toMap() {}


}

class ProductList extends StatefulWidget {
  @override
  _ProductListState createState() => _ProductListState();
}

class _ProductListState extends State<ProductList> {
  List<Product> _products = [];

  Future<List<Product>> fetchProducts() async {
    final response =
    await http.get(Uri.parse('https://my-backend-api.com/products'));
    if (response.statusCode == 200) {
      List<dynamic> jsonList = json.decode(response.body);
      return jsonList.map((json) => Product.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load products');
    }
  }

  void addProduct(Product product) async {
    final response = await http.post(
      Uri.parse('https://my-backend-api.com/products'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, dynamic>{
        'name': product.name,
        'description': product.description,
        'price': product.price,
        'imageUrl': product.imageUrl,
      }),
    );
    if (response.statusCode == 201) {
      setState(() {
        _products.add(product);
      });
    } else {
      throw Exception('Failed to add product');
    }
  }

  void deleteProduct(Product product) async {
    final response = await http.delete(
      Uri.parse('https://my-backend-api.com/products/${product.id}'),
    );
    if (response.statusCode == 204) {
      setState(() {
        _products.remove(product);
      });
    } else {
      throw Exception('Failed to delete product');
    }
  }

  void updateProduct(Product product) async {
    final response = await http.put(
      Uri.parse('https://my-backend-api.com/products/${product.id}'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, dynamic>{
        'name': product.name,
        'description': product.description,
        'price': product.price,
        'imageUrl': product.imageUrl,
      }),
    );
    if (response.statusCode == 200) {
      setState(() {
        _products[_products.indexWhere((p) => p.id == product.id)] = product;
      });
    } else {
      throw Exception('Failed to update product');
    }
  }

  @override
  void initState() {
    super.initState();
    fetchProducts().then((products) {
      setState(() {
        _products = products;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
        title: Text('Product List'),
    ),
    body: ListView.builder(
    itemCount: _products.length,
    itemBuilder: (BuildContext context, int index) {
    return ListTile(
    title: Text(_products[index].name),
    subtitle: Text(_products[index].description),
    trailing: IconButton(
    icon: Icon (Icons.delete),
      onPressed: () => deleteProduct(_products[index]),
    ),
      onTap: () async {
        Product updatedProduct = await showDialog(
          context: context,
          builder: (BuildContext context) => EditProductDialog(
            product: _products[index],
          ),
        );
        if (updatedProduct != null) {
          updateProduct(updatedProduct);
        }
      },
    );
    },
    ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () async {
          Product newProduct = await showDialog(
            context: context,
            builder: (BuildContext context) => AddProductDialog(),
          );
          if (newProduct != null) {
            addProduct(newProduct);
          }
        },
      ),
    );
  }
}

class AddProductDialog extends StatefulWidget {
  @override
  _AddProductDialogState createState() => _AddProductDialogState();
}

class _AddProductDialogState extends State<AddProductDialog> {
  final _formKey = GlobalKey<FormState>();
  late String _name;
  late String _description;
  late double _price;
  late String _imageUrl;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Add Product'),
      content: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            TextFormField(
              decoration: InputDecoration(labelText: 'Name'),
              validator: (value) {
                if (value!.isEmpty) {
                  return 'Please enter a name';
                }
                return null;
              },
              onSaved: (value) {
                setState(() {
                  _name = value!;
                });
              },
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Description'),
              validator: (value) {
                if (value!.isEmpty) {
                  return 'Please enter a description';
                }
                return null;
              },
              onSaved: (value) {
                setState(() {
                  _description = value!;
                });
              },
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Price'),
              validator: (value) {
                if (value!.isEmpty) {
                  return 'Please enter a price';
                }
                if (double.tryParse(value) == null) {
                  return 'Please enter a valid price';
                }
                return null;
              },
              onSaved: (value) {
                setState(() {
                  _price = double.parse(value!);
                });
              },
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Image URL'),
              onSaved: (value) {
                setState(() {
                  _imageUrl = value!;
                });
              },
            ),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          child: Text('Cancel'),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        TextButton(
          child: Text('Save'),
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              _formKey.currentState!.save();
              Navigator.of(context).pop(
                Product(
                  name: _name,
                  description: _description,
                  price: _price,
                  imageUrl: _imageUrl, id: 1,
                ),
              );
            }
          },
        ),
      ],
    );
  }
}

class EditProductDialog extends StatefulWidget {
  final Product product;

  EditProductDialog({required this.product});

  @override
  _EditProductDialogState createState() => _EditProductDialogState();
}

class _EditProductDialogState extends State<EditProductDialog> {
  final _formKey = GlobalKey<FormState>();
  late String _name;
  late String _description;
  late double _price;
  late String _imageUrl;

  @override
  void initState() {
    super.initState();
    _name =widget.product.name;
    _description = widget.product.description;
    _price = widget.product.price;
    _imageUrl = widget.product.imageUrl;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Edit Product'),
      content: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            TextFormField(
              decoration: InputDecoration(labelText: 'Name'),
              initialValue: _name,
              validator: (value) {
                if (value!.isEmpty) {
                  return 'Please enter a name';
                }
                return null;
              },
              onSaved: (value) {
                setState(() {
                  _name = value!;
                });
              },
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Description'),
              initialValue: _description,
              validator: (value) {
                if (value!.isEmpty) {
                  return 'Please enter a description';
                }
                return null;
              },
              onSaved: (value) {
                setState(() {
                  _description = value!;
                });
              },
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Price'),
              initialValue: _price.toString(),
              validator: (value) {
                if (value!.isEmpty) {
                  return 'Please enter a price';
                }
                if (double.tryParse(value) == null) {
                  return 'Please enter a valid price';
                }
                return null;
              },
              onSaved: (value) {
                setState(() {
                  _price = double.parse(value!);
                });
              },
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Image URL'),
              initialValue: _imageUrl,
              onSaved: (value) {
                setState(() {
                  _imageUrl = value!;
                });
              },
            ),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          child: const Text('Cancel'),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        TextButton(
          child: const Text('Save'),
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              _formKey.currentState!.save();
              Navigator.of(context).pop(
                Product(
                  id: widget.product.id,
                  name: _name,
                  description: _description,
                  price: _price,
                  imageUrl: _imageUrl,
                ),
              );
            }
          },
        ),
      ],
    );
  }
}
