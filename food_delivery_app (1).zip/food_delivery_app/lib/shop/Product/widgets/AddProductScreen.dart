// screens/add_product_screen.dart

import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/functions/download_url.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';

import '../../../auth/splashScreen/splash_screen.dart';
import 'ViewProduct.dart';


class AddProductScreen extends StatefulWidget {
  @override
  _AddProductScreenState createState() => _AddProductScreenState();

  final String shopId;


  AddProductScreen(this.shopId);
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _formKey = GlobalKey<FormState>();
  late String _productName;
  late double _price;
  late String _description;
  late String _image;

  File? imageFile;

  void _submitForm() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      // final product = Product(
      //   name: _productName,
      //   price: _price,
      //   description: _description,
      // );

      final productId = const Uuid().v1();

      _image = await getImageUrl(imageFile!);

      FirebaseFirestore.instance.collection('products').doc(productId).set(
        {
          'id': productId,
          'shopId': widget.shopId,
          'name': _productName,
          'price': _price,
          'description': _description,
          'imageUrl': _image,
          'created_at': DateTime.now(),
          'updated_at': DateTime.now(),
        },
        SetOptions(merge: true),
      );

      Navigator.of(context).pop();
      Navigator.of(context).push(MaterialPageRoute(builder: (context) => ViewProduct(shopId: widget.shopId, productId: productId)));


    }
  }

  final picker = ImagePicker();

  Future<void> pickImage() async {
    final XFile? pickedFile = await picker.pickImage(
      source: ImageSource.gallery,
    );

    if (pickedFile != null) {
      imageFile = File(pickedFile.path);
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Product'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: 'Product Name'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a valid product name.';
                  }
                  return null;
                },
                onSaved: (value) {
                  _productName = value!;
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Price'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a valid price.';
                  }
                  return null;
                },
                onSaved: (value) {
                  _price = double.parse(value!);
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Description'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a valid description.';
                  }
                  return null;
                },
                onSaved: (value) {
                  _description = value!;
                },
              ),
              // TextFormField(
              //   decoration: InputDecoration(labelText: 'Image'),
              //   validator: (value) {
              //     if (value == null || value.isEmpty) {
              //       return 'Please enter a valid image URL.';
              //     }
              //     return null;
              //   },
              //   onSaved: (value) {
              //     _image = value!;
              //   },
              // ),
              SizedBox(height: 16.0),
              if (imageFile == null)
                InkWell(
                  onTap: () {
                    pickImage();
                  },
                  child: const Text('Pick Image'),
                ),
              if (imageFile != null)
                Image.file(
                  imageFile!,
                  height: 200,
                ),
              SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: _submitForm,
                child: Text('Add Product'),
              ),


            ],
          ),
        ),
      ),
    );
  }
}
