// class _EditProductScreenState extends State<EditProductScreen> {
//   final _formKey = GlobalKey<FormState>();
//   final _nameController = TextEditingController();
//   final _priceController = TextEditingController();
//   File? _imageFile;
//
//   bool _isLoading = false;
//
//   @override
//   void initState() {
//     super.initState();
//
//     // Load the product data from Firestore when the screen is first loaded
//     FirebaseFirestore.instance
//         .collection('products')
//         .doc(widget.productId)
//         .get()
//         .then((doc) {
//       if (doc.exists) {
//         _nameController.text = doc['name'];
//         _priceController.text = doc['price'].toString();
//       }
//     }).catchError((error) {
//       // Handle errors
//     });
//   }
//
//   void _saveProduct() async {
//     if (!_formKey.currentState!.validate()) {
//       return;
//     }
//
//     setState(() {
//       _isLoading = true;
//     });
//
//     // Upload the image to Firebase Storage, if an image was selected
//     String? imageUrl;
//     if (_imageFile != null) {
//       final ref = FirebaseStorage.instance
//           .ref()
//           .child('product_images')
//           .child('${widget.shopId}_${widget.productId}.jpg');
//       await ref.putFile(_imageFile!);
//       imageUrl = await ref.getDownloadURL();
//     }
//
//     // Update the product data in Firestore
//     await FirebaseFirestore.instance
//         .collection('products')
//         .doc(widget.productId)
//         .update({
//       'name': _nameController.text,
//       'price': double.parse(_priceController.text),
//       'imageUrl': imageUrl ?? '',
//     }).then((value) {
//       Navigator.of(context).pop();
//     }).catchError((error) {
//       // Handle errors
//     });
//
//     setState(() {
//       _isLoading = false;
//     });
//   }
//
//   void _pickImage() async {
//     final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
//
//     if (pickedFile != null) {
//       setState(() {
//         _imageFile = File(pickedFile.path);
//       });
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Edit Product'),
//       ),
//       body: _isLoading
//           ? Center(child: CircularProgressIndicator())
//           : SingleChildScrollView(
//         padding: EdgeInsets.all(16),
//         child: Form(
//           key: _formKey,
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.stretch,
//             children: [
//               // Product name
//               TextFormField(
//                 controller: _nameController,
//                 decoration: InputDecoration(labelText: 'Product Name'),
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Please enter a product name.';
//                   }
//                   return null;
//                 },
//               ),
//
//               SizedBox(height: 16),
//
//               // Product price
//               TextFormField(
//                 controller: _priceController,
//                 decoration: InputDecoration(labelText: 'Price'),
//                 keyboardType: TextInputType.number,
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Please enter a price.';
//                   }
//                   if (double.tryParse(value) == null) {
//                     return 'Please enter a valid price.';
//                   }
//                   return null;
//                 },
//               ),
//
//               SizedBox(height: 16),
//
//               // Product image
//               if (_imageFile != null)
//                 Image.file(
//                   _imageFile!,
//                   height: 150,
//                 ),
//
//               SizedBox(height: 8),
//
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   TextButton.icon(
//                     onPressed: _pickImage,
//                     icon: Icon(Icons.photo),
//                     label: Text('Select Image'),
//                   ),
//                   // Clear image button
//                   if (_imageFile != null)
//                     TextButton.icon(
//                       onPressed: () {
//                         setState(() {
//                           _imageFile = null;
//                         });
//                       },
//                       icon: Icon(Icons.clear),
//                       label: Text('Clear Image'),
//                     ),
//                 ],
//               ),
//
//               SizedBox(height: 32),
//
//               // Save button
//               ElevatedButton(
//                 onPressed: _saveProduct,
//                 child: Text('Save Product'),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
