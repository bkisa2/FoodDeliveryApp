// create_shop_screen.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/global/global.dart';
import 'package:food_delivery_app/shop/ShopScreen.dart';
import 'package:uuid/uuid.dart';

import '../../../models/shop.dart';

class CreateShopScreen extends StatefulWidget {
  const CreateShopScreen({Key? key}) : super(key: key);

  @override
  _CreateShopScreenState createState() => _CreateShopScreenState();
}

class _CreateShopScreenState extends State<CreateShopScreen> {
  final _formKey = GlobalKey<FormState>();

  late String _ownerName;
  late String _shopName;
  late String _address;
  late String _phoneNumber;

  void _createShop() {
    if (_formKey.currentState!.validate()) {
      final newShop = Shop(
        ownerName: _ownerName,
        shopName: _shopName,
        address: _address,
        phoneNumber: _phoneNumber,
        products: [],
        id:  FirebaseFirestore.instance.collection('shops').doc().id,

      );

      final shopId = const Uuid().v1();

      FirebaseFirestore.instance.collection('shops').doc(shopId).set(
        {
          'id': shopId,
          'ownerName': _ownerName,
          'shopName': _shopName,
          'address': _address,
          'phoneNumber': _phoneNumber,
          'products': [],
          'created_at': DateTime.now(),
          'updated_at': DateTime.now(),
        },
        SetOptions(merge: true),
      );

      navigate(
          context,
          ShopScreen(
            shop: newShop,
            shopId: shopId,
          ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create Shop'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter owner name';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'Owner Name',
                ),
                onChanged: (value) {
                  _ownerName = value;
                },
              ),
              TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter shop name';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'Shop Name',
                ),
                onChanged: (value) {
                  _shopName = value;
                },
              ),
              TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter address';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'Address',
                ),
                onChanged: (value) {
                  _address = value;
                },
              ),
              TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter phone number';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'Phone Number',
                ),
                onChanged: (value) {
                  _phoneNumber = value;
                },
              ),
              SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: _createShop,
                child: Text('Create Shop'),
              ),
              SizedBox(height: 16.0),
              // ElevatedButton(
              //   onPressed: (){
              //     navigate(context,ShopLoginScreen());
              //   },
              //   child: Text('Login to Shop'),
              // ),
            ],
          ),
        ),
      ),
    );
  }
}
