import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ViewProductDetails extends StatelessWidget {
  final String shopId;
  final String productId;

  const ViewProductDetails({Key? key, required this.shopId, required this.productId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Product Details'),
      ),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('products').doc(productId).snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          final product = snapshot.data?.data();

          if (product == null) {
            return Center(child: Text('Product not found.'));
          }

          return Column(
            children: [
              SizedBox(height: 20),
              Image.network(
                product['imageUrl'] ?? '',
                height: 300,
                width: 300,
              ),
              SizedBox(height: 20),
              Text(
                product['name'] ?? '',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20),
              Text(
                'Price: ${product['price'] ?? ''}',
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
              SizedBox(height: 20),
              Text(
                product['description'] ?? '',
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
