// shop_login_screen.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/global/global.dart';
import 'package:food_delivery_app/shop/ShopScreen.dart';

import '../../../../models/shop.dart';
import '../widgets/CreateShopScreen.dart';

class ShopLoginScreen extends StatefulWidget {
  const ShopLoginScreen({Key? key}) : super(key: key);

  @override
  _ShopLoginScreenState createState() => _ShopLoginScreenState();
}

class _ShopLoginScreenState extends State<ShopLoginScreen> {
  final _formKey = GlobalKey<FormState>();

  late String _ownerName;
  late String _shopName;
  late String _address;
  late String _phoneNumber;

  void _loginToShop() async {
    if (_formKey.currentState!.validate()) {
      final querySnapshot = await FirebaseFirestore.instance
          .collection('shops')
          .where('ownerName', isEqualTo: _ownerName)
          .where('shopName', isEqualTo: _shopName)
          .where('address', isEqualTo: _address)
          .where('phoneNumber', isEqualTo: _phoneNumber)
          .get();
      if (querySnapshot.docs.isNotEmpty) {
        final shop = Shop.fromSnapshot(querySnapshot.docs.first);

        navigate(
          context,
          ShopScreen(
            shop: shop,
            shopId: shop.id,
          ),
        );
      } else {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Data Not Found'),
              content: Text('The provided login information does not match any shop data.'),
              actions: [
                TextButton(
                  child: Text('OK'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ],
            );
          },
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Shop Login'),
      ),
      body:Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Food On-line',
                style: TextStyle(
                  fontSize: 50,
                  color: Colors.amber,
                  shadows: [
                    BoxShadow(
                      blurRadius: 5,
                      color: Colors.green.shade900,
                      offset: Offset(3, 3),
                    )
                  ],
                ),
              ),
              SizedBox(height: 16.0),
              TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter owner name';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'Owner Name',
                ),
                onChanged: (value) {
                  setState(() {
                    _ownerName = value;
                  });
                },
              ),
              TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter shop name';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'Shop Name',
                ),
                onChanged: (value) {
                  setState(() {
                    _shopName = value;
                  });
                },
              ),
              TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter address';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'Address',
                ),
                onChanged: (value) {
                  setState(() {
                    _address = value;
                  });
                },
              ),
              TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter phone number';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'Phone Number',
                ),
                onChanged: (value) {
                  setState(() {
                    _phoneNumber = value;
                  });
                },
              ),
              SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: _loginToShop,
                child: Text('Login to Shop'),
              ),
              ElevatedButton(
                onPressed: () {
                  navigate(context, CreateShopScreen());
                },
                child: Text('Create Shop'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
