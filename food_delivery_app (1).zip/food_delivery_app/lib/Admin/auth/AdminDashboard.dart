import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class AdminDashboard extends StatefulWidget {
  @override
  _AdminDashboardState createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Food Online'),
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            ListTile(
              title: Text('User Information'),
              onTap: () {
                // Handle user information page navigation
              },
            ),
            // ListTile(
            //   title: Text('Shop Details'),
            //   onTap: () {
            //     Navigator.push(context, MaterialPageRoute(builder: (context) => ShopListPage()));
            //   },
            // ),
            ListTile(
              title: Text('Driver Details'),
              onTap: () {
                // Handle driver details page navigation
              },
            ),
            ListTile(
              title: Text('Product Details'),
              onTap: () {
                // Handle product details page navigation
              },
            ),
            ListTile(
              title: Text('Write Details'),
              onTap: () {
                // Handle write details page navigation
              },
            ),
            ListTile(
              title: Text('Logout'),
              onTap: () {
                _logout();
              },
            ),
          ],
        ),
      ),
      body: Center(
        child: Text('Admin Dashboard'),
      ),
    );
  }

  void _logout() async {
    await FirebaseAuth.instance.signOut();
    // Navigate to the login page or any other desired screen
  }
}
