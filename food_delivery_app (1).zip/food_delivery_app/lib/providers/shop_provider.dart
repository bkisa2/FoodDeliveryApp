import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';

import '../models/shop.dart';

class ShopProvider with ChangeNotifier
{

  List<Shop>ShopList =[];
  late Shop shopModel;

  fetchShopData()async{
    QuerySnapshot value = await FirebaseFirestore.instance.collection("shops").get();

    value.docs.forEach((element) {

      // shopModel = Shop(
      //     ownerName: ownerName,
      //     shopName: shopName,
      //     address: address,
      //     phoneNumber: phoneNumber,
      //     products: products)

    },
    );
  }
}