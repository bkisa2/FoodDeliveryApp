import 'package:flutter/material.dart';
import 'package:get/get.dart';

class RideScheduleController extends GetxController {

  final now = DateTime.now();
  final selectedDate = DateTime.now().obs;

  final timeNow = TimeOfDay.now();


  // final selectedTime = TimeOfDay.now().obs;

  Future<void> selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: timeNow,
    );

    if (picked != null) {
      DateTime dt = selectedDate.value;

      selectedDate.value =
          DateTime(dt.year, dt.month, dt.day, picked.hour, picked.minute);
    }
  }

  Future<void> selectDate(BuildContext context) async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: now,
      lastDate: DateTime(2101),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: Colors.amberAccent, // <-- SEE HERE
              onPrimary: Colors.white, // <-- SEE HERE
              onSurface: Colors.black, // <-- SEE HERE
            ),
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                primary: Colors.red, // button text color
              ),
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != selectedDate.value) {
      selectedDate.value = picked;
      selectedDate.value = DateTime(
          picked.year, picked.month, picked.day, picked.hour, picked.minute);
    }
  }
}
