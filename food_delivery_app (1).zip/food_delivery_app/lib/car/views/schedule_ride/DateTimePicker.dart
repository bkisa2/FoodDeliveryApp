import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import 'HomePage.dart';

class PickupPage extends StatefulWidget {
  final String driverId;
  final DocumentSnapshot carDetails;

  const PickupPage({
    Key? key,
    required this.driverId,
    required this.carDetails,

  }) : super(key: key);

  @override
  _PickupPageState createState() => _PickupPageState();
}

class _PickupPageState extends State<PickupPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _stationNameController = TextEditingController();
  final _destinationController = TextEditingController();
  final _phoneController = TextEditingController();
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  String? driverName;
  String? driverPhoneNumber;

  @override
  void initState() {
    super.initState();
    _fetchDriverInfo();
  }


  @override
  void dispose() {
    _nameController.dispose();
    _stationNameController.dispose();
    _destinationController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _fetchDriverInfo() async {
    final driverSnapshot = await FirebaseFirestore.instance
        .collection('drivers')
        .doc(widget.driverId)
        .get();

    if (driverSnapshot.exists) {
      setState(() {
        driverName = driverSnapshot['name'];
        driverPhoneNumber = driverSnapshot['phoneNumber'];
      });
    }
  }


  Future<void> _saveData() async {
    final name = _nameController.text;
    final stationName = _stationNameController.text;
    final destination = _destinationController.text;
    final phone = _phoneController.text;
    final pickupTime = DateTime(
      _selectedDate.year,
      _selectedDate.month,
      _selectedDate.day,
      _selectedTime.hour,
      _selectedTime.minute,
    );
    final uuid = Uuid().v4();
    final userId = FirebaseAuth.instance.currentUser!.uid;
    final pickupRef = FirebaseFirestore.instance
        .collection('riders')
        .doc(userId)
        .collection('RideBook')
        .doc(uuid);

    // Fetch driver's name and phone number from Firestore
    final driverSnapshot = await FirebaseFirestore.instance
        .collection('drivers')
        .doc(widget.driverId)
        .get();
    final fetchedDriverName = driverSnapshot['name'];
    final fetchedDriverPhoneNumber = driverSnapshot['phoneNumber'];

    await pickupRef.set({
      'hourlyRate': widget.carDetails.get('hourlyRate'),
      'carNumber': widget.carDetails.get('carNumber'),
      "uid": FirebaseAuth.instance.currentUser!.uid,
      'userName': name,
      'stationName': stationName,
      'destination': destination,
      'phoneNumber': phone,
      'pickupTime': pickupTime,
      'driverName': fetchedDriverName,
      'driverPhoneNumber': fetchedDriverPhoneNumber,
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Data saved successfully!'),
        duration: Duration(seconds: 2),
      ),
    );Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => HomePageCar()),
          (route) => false,
    );
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now().subtract(Duration(days: 1)), // Updated line
      lastDate: DateTime.now().add(Duration(days: 365)),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

    Future<void> _selectTime() async {
      final TimeOfDay? picked = await showTimePicker(
        context: context,
        initialTime: _selectedTime,
      );
      if (picked != null && picked != _selectedTime) {
        setState(() {
          _selectedTime = picked;
        });
      }
    }

    @override
    Widget build(BuildContext context) {
      return Scaffold(
        appBar: AppBar(
          title: Text('Schedule a Pickup'),
        ),
        body: Form(
          key: _formKey,
          child: ListView(
            padding: EdgeInsets.all(16),
            children: [
              Center(
                child: Text('Driver Details',
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Colors.amber,
                  ),
                ),
              ),
              Text(
                'Driver: ${driverName ?? ''}',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              SizedBox(height: 16),
              Text(
                'Driver: ${widget.carDetails.get('carModel')}',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              SizedBox(height: 16),
              Text(
                'Driver: ${widget.carDetails.get('carNumber')}',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              SizedBox(height: 16),
              Text(
                'Driver: ${widget.carDetails.get('hourlyRate')}',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              SizedBox(height: 16),

              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(labelText: 'Your name'),
                validator: (value) {
                  if (value?.isEmpty ?? true) {
                    return 'Please enter your name';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _stationNameController,
                decoration: InputDecoration(labelText: 'Station name'),
                validator: (value) {
                  if (value?.isEmpty ?? true) {
                    return 'Please enter the station name';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _destinationController,
                decoration: InputDecoration(labelText: 'Destination address'),
                validator: (value) {
                  if (value?.isEmpty ?? true) {
                    return 'Please enter the destination address';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _phoneController,
                decoration: InputDecoration(labelText: 'Phone number'),
                validator: (value) {
                  if (value?.isEmpty ?? true) {
                    return 'Please enter your phone number';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => _selectDate(),
                      child: AbsorbPointer(
                        child: TextFormField(
                          decoration: InputDecoration(
                            labelText: 'Pickup date',
                            suffixIcon: Icon(Icons.calendar_today),
                          ),
                          controller: TextEditingController(
                            text: DateFormat.yMd().format(_selectedDate),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => _selectTime(),
                      child: AbsorbPointer(
                        child: TextFormField(
                          decoration: InputDecoration(
                            labelText: 'Pickup time',
                            suffixIcon: Icon(Icons.access_time),
                          ),
                          controller: TextEditingController(
                            text: TimeOfDay(
                              hour: _selectedTime.hour,
                              minute: _selectedTime.minute,
                            ).format(context),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState != null &&
                      _formKey.currentState!.validate()) {
                    _saveData();
                  }
                },
                child: Text('Confirm Ride'),
              ),
            ],
          ),
        ),
      );
    }
  }

