import 'package:flutter/material.dart';

class BookCarScreen extends StatelessWidget {
  final String driverName;
  final String carMakeAndModel;
  final String pickupLocation;
  final String pickupTime;

  const BookCarScreen({
    Key? key,
    required this.driverName,
    required this.carMakeAndModel,
    required this.pickupLocation,
    required this.pickupTime,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Book Car'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            'Driver: $driverName',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 16),
          Text(
            'Car: $carMakeAndModel',
            style: TextStyle(
              fontSize: 18,
            ),
          ),
          SizedBox(height: 16),
          Text(
            'Pickup Location: $pickupLocation',
            style: TextStyle(
              fontSize: 18,
            ),
          ),
          SizedBox(height: 16),
          Text(
            'Pickup Time: $pickupTime',
            style: TextStyle(
              fontSize: 18,
            ),
          ),
          SizedBox(height: 32),
          ElevatedButton(
            onPressed: () {
              // TODO: implement booking logic
            },
            child: Text('Book Now'),
          ),
        ],
      ),
    );
  }
}
