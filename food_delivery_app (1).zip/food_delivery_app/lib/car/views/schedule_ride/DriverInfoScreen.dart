import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/widgets.dart';

import '../../../models/driver.dart';
import 'driver register/DriverDashboard.dart';

class DriverInfoScreen extends StatelessWidget {
  final Driver driver;

  const DriverInfoScreen({required this.driver});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Driver Info'),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SizedBox(height: 10),
              Text(
                'Name: ${driver.name}',
                style: TextStyle(fontSize: 20),
              ),
              SizedBox(height: 10),
              Text(
                'Phone Number: ${driver.phoneNumber}',
                style: TextStyle(fontSize: 20),
              ),
              SizedBox(height: 10),
              Container(
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DriverDashboard(
                          driverId: driver.id,
                          driver: driver,
                        ),
                      ),
                    );
                  },
                  child: Text('Driver Dashboard'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
