import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class RideHistoryPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ride History'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('riders')
            .doc(FirebaseAuth.instance.currentUser!.uid)
            .collection('RideBook')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Text('Error: ${snapshot.error}');
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return CircularProgressIndicator();
          }

          if (snapshot.hasData && snapshot.data!.docs.isEmpty) {
            return Center(child: Text('No ride history found'));
          }

          return ListView.builder(
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              DocumentSnapshot rideData = snapshot.data!.docs[index];

              DateTime pickupTime = rideData['pickupTime'].toDate();

              String formattedDate = DateFormat.yMd().format(pickupTime);
              String formattedTime = DateFormat.jm().format(pickupTime);

              return Card(
                elevation: 2,
                margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                child: ListTile(
                  // leading: Image.network(
                  //   'https://www.appreviewsbucket.com/blog/wp-content/uploads/2020/05/Ride-Sharing-Apps.jpg',
                  //   width: 60,
                  //   height: 60,
                  // ),
                  title: Text(
                    'Driver: ${rideData['driverName']}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 8),
                      Text(
                        'Hourly Rate: ${rideData['hourlyRate']}',
                        style: TextStyle(fontSize: 16),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Phone Number: ${rideData['driverPhoneNumber']}',
                        style: TextStyle(fontSize: 16),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Car Number: ${rideData['carNumber']}',
                        style: TextStyle(fontSize: 16),
                      ),
                      SizedBox(height: 8),
                      Divider(color: Colors.grey),
                      SizedBox(height: 8),
                      Text(
                        'Pickup Date: $formattedDate',
                        style: TextStyle(fontSize: 16),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Pickup Time: $formattedTime',
                        style: TextStyle(fontSize: 16),
                      ),
                      SizedBox(height: 8),
                    ],
                  ),
                  onTap: () {
                    // Handle on tap event, if needed
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
