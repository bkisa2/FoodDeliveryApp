// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:intl/intl.dart';
// import 'package:uuid/uuid.dart';
//
// import '../../../models/RideSchedule.dart';
// import '../../../widgets/spacer.dart';
// import '../../controllers/ride_schedule_controller.dart';
// import '../../global/colors.dart';
// import 'HomePage.dart';
// import 'driver register/MapScreen.dart';
//
// class ScheduleRidePage extends StatefulWidget {
//   const ScheduleRidePage({Key? key}) : super(key: key);
//
//   @override
//   State<ScheduleRidePage> createState() => _ScheduleRidePageState();
// }
//
// class _ScheduleRidePageState extends State<ScheduleRidePage> {
//   final controller = RideScheduleController();
//   final _formKey = GlobalKey<FormState>();
//
//   late String _userName;
//   late String _phoneNumber;
//   late String _stationName;
//   late String _destination;
//   // late String _pickupTime;
//
//   void _setUserInfo() {
//     if (_formKey.currentState!.validate()) {
//       // final _newUserInfo = RideSchedule(
//       //   pickupTime: _pickupTime,
//       //   stationName: _stationName,
//       //   destination: _destination,
//       //   phoneNumber: int.parse(_phoneNumber),
//       //   userName: _userName,
//       //  // pickupDate:DateTime.parse(_pickupDate) ,
//       // );
//
//       final UserInfoId = const Uuid().v1();
//
//       FirebaseFirestore.instance.collection('setUserInfo').doc(UserInfoId).set(
//         {
//           'id': UserInfoId,
//           'userName': _userName,
//           'phoneNumber': _phoneNumber,
//           'stationName': _stationName,
//           'destination': _destination,
//           //'pickupTime': _pickupTime,
//           'created_at': DateTime.now(),
//           'updated_at': DateTime.now(),
//         },
//
//         SetOptions(merge: true),
//       );
//
//       Navigator.push(
//         context,
//         MaterialPageRoute(
//           builder: (context) => HomePageCar(),
//         ),
//       );
//     }
//   }
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('User Information'),
//         backgroundColor: Colors.amber,
//       ),
//       body: SingleChildScrollView(
//         child: Form(
//           key: _formKey,
//           child: Column(
//             children: [
//               const VerticalSpacer(24),
//               const Text(
//                 'Schedule a Ride',
//                 style: TextStyle(
//                   fontSize: 20,
//                   fontWeight: FontWeight.w900,
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: Container(
//                   decoration: BoxDecoration(
//                     color: MyColors.black.withOpacity(0.05),
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       Padding(
//                         padding: const EdgeInsets.all(20.0),
//                         child: Obx(
//                               () => Text(
//                             DateFormat('MMMM dd, y').format(
//                               controller.selectedDate.value,
//                             ),
//                           ),
//                         ),
//                       ),
//                       IconButton(
//                         icon: const Icon(Icons.calendar_month_outlined),
//                         onPressed: () {
//                           controller.selectDate(context);
//                         },
//                       )
//                     ],
//                   ),
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.only(left: 16, right: 16),
//                 child: Container(
//                   decoration: BoxDecoration(
//                     color: MyColors.black.withOpacity(0.05),
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       Padding(
//                         padding: const EdgeInsets.all(20.0),
//                         child: Obx(
//                               () => Text(
//                             DateFormat('hh:mma').format(
//                               controller.selectedDate.value,
//                             ),
//                           ),
//                         ),
//                       ),
//                       IconButton(
//                         icon: const Icon(Icons.timer),
//                         onPressed: () {
//                           controller.selectTime(context);
//                         },
//                       )
//                     ],
//                   ),
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: TextFormField(
//                   decoration: InputDecoration(
//                     border: OutlineInputBorder(),
//                     labelText: 'Enter your station name',
//                   ),
//                   validator: (value) {
//                     if (value == null || value.isEmpty) {
//                       return 'Please enter a station name';
//                     }
//                     return null;
//                   },
//                   onSaved: (value) {
//                     _stationName = value!;
//                   },
//                 ),
//               ),
//
//               Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: TextFormField(
//                   decoration: InputDecoration(
//                     border: OutlineInputBorder(),
//                     labelText: 'Where to go?',
//                   ),
//                   validator: (value) {
//                     if (value == null || value.isEmpty) {
//                       return 'Please enter a destination';
//                     }
//                     return null;
//                   },
//                   onSaved: (value) {
//                     _destination = value!;
//                   },
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: TextFormField(
//                   decoration: InputDecoration(
//                     border: OutlineInputBorder(),
//                     labelText: 'UserName',
//                   ),
//                   validator: (value) {
//                     if (value == null || value.isEmpty) {
//                       return 'Please enter a name';
//                     }
//                     return null;
//                   },
//                   onSaved: (value) {
//                     _userName = value!;
//                   },
//                 ),
//               ),
//
//
//               Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: TextFormField(
//                   decoration: InputDecoration(
//                     border: OutlineInputBorder(),
//                     labelText: 'Pone Number?',
//                   ),
//                   validator: (value) {
//                     if (value == null || value.isEmpty) {
//                       return 'Please enter a phone Number';
//                     }
//                     return null;
//                   },
//                   onSaved: (value) {
//                     _phoneNumber = value!;
//                   },
//                 ),
//               ),
//
//               ElevatedButton(
//                 onPressed: () {
//                   Navigator.push(context, MaterialPageRoute(builder: (context) => MapScreen()));
//                 },
//                 child: Text('Map'),
//               ),
//
//               Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: ElevatedButton(
//                   onPressed: _setUserInfo,
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: MyColors.prime,
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(32),
//                     ),
//                     minimumSize: Size(MediaQuery.of(context).size.width, 52),
//                   ),
//
//
//                   child: const Text(
//                     'Set Pickup Time',
//                     style: TextStyle(
//                       color: MyColors.black,
//                       fontSize: 16,
//                       fontWeight: FontWeight.w600,
//                     ),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//
//
//       ),
//     );
//   }
// }
//
//
