import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';

import '../../../functions/download_url.dart';
import '../../../models/driver.dart';
import 'DriverInfoScreen.dart';

class RegisterDriverScreen extends StatefulWidget {
  const RegisterDriverScreen({Key? key}) : super(key: key);

  @override
  _RegisterDriverScreenState createState() => _RegisterDriverScreenState();
}

class _RegisterDriverScreenState extends State<RegisterDriverScreen> {
  final _formKey = GlobalKey<FormState>();

  late String _name;
  late String _phoneNumber;
  late String _password;


  File? imageFile;


  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      final driverId = const Uuid().v1();

      final storeDriver = Driver(
        name: _name,
        phoneNumber: _phoneNumber,
        password: _password,
        id: driverId,
        carDetailsId: '',

      );

      await FirebaseFirestore.instance.collection('drivers').doc(driverId).set(
        {
          'id': driverId,
          'name': _name,
          'phoneNumber': _phoneNumber,
          'password': _password,
          'created_at': DateTime.now(),
          'updated_at': DateTime.now(),
        },
        SetOptions(merge: true),
      );

      Navigator.of(context).pop();
      Navigator.of(context).push(MaterialPageRoute(builder: (context) => DriverInfoScreen(driver: storeDriver)));
    }
  }

  // final picker = ImagePicker();
  //
  // Future<void> pickImage() async {
  //   final XFile? pickedFile = await picker.pickImage(
  //     source: ImageSource.gallery,
  //   );
  //
  //   if (pickedFile != null) {
  //     imageFile = File(pickedFile.path);
  //     setState(() {});
  //   }
  // }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Driver Registration'),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 16.0),
                  // SizedBox(height: 16.0),
                  //
                  // if (imageFile == null)
                  //   InkWell(
                  //     onTap: () {
                  //       pickImage();
                  //     },
                  //     child: const Text('Pick Image'),
                  //   ),
                  // if (imageFile != null)
                  //   Image.file(
                  //     imageFile!,
                  //     height: 200,
                  //   ),

                  const SizedBox(height: 16.0),
                  TextFormField(
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter name';
                      }
                      return null;
                    },
                    decoration: const InputDecoration(
                      labelText: 'Name',
                    ),
                    onChanged: (value) {
                      _name = value;
                    },
                  ),
                  const SizedBox(height: 16.0),
                  TextFormField(
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter phone number';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      labelText: 'Phone Number',
                    ),
                    onChanged: (value) {
                      _phoneNumber = value;
                    },
                  ),

                  SizedBox(height: 8.0),
                  TextFormField(
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter Password';
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      labelText: 'Password',
                    ),
                    onChanged: (value) {
                      _password = value;
                    },
                  ),

                  SizedBox(height: 24.0),
                  ElevatedButton(
                    onPressed: _submitForm,
                    child: Text('Register Driver'),
                  ),
                  SizedBox(height: 16.0),
                ],
              ),
            ),
          ),
        )
    );
  }
}