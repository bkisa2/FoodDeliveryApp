// import 'dart:async';
//
// import 'package:flutter/material.dart';
// import 'package:geocoding/geocoding.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:url_launcher/url_launcher.dart';
//
// class MapScreen extends StatefulWidget {
//   @override
//   _MapScreenState createState() => _MapScreenState();
// }
//
// class _MapScreenState extends State<MapScreen> {
//   Completer<GoogleMapController> _controller = Completer();
//   final TextEditingController _addressController = TextEditingController();
//   LatLng _center = LatLng(37.42796133580664, -122.085749655962);
//   Set<Marker> _markers = {};
//
//   void _onSearchButtonPressed() async {
//     final query = _addressController.text;
//     List<Location> locations = await locationFromAddress(query);
//     if (locations != null && locations.isNotEmpty) {
//       final Location pos = locations[0];
//       setState(() {
//         _markers.clear();
//         final marker = Marker(
//           markerId: MarkerId('Current Location'),
//           position: LatLng(pos.latitude, pos.longitude),
//           infoWindow: InfoWindow(title: query),
//           icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
//         );
//         _markers.add(marker);
//         _center = LatLng(pos.latitude, pos.longitude);
//       });
//     }
//   }
//
//   void _onDirectionsButtonPressed() async {
//     final query = _addressController.text;
//     List<Location> locations = await locationFromAddress(query);
//     if (locations != null && locations.isNotEmpty) {
//       final Location pos = locations[0];
//       final url =
//           'https://www.google.com/maps/dir/?api=1&destination=${pos.latitude},${pos.longitude}';
//       if (await canLaunch(url)) {
//         await launch(url);
//       } else {
//         throw 'Could not launch $url';
//       }
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Map Screen'),
//       ),
//       body: Stack(
//         children: [
//           GoogleMap(
//             mapType: MapType.normal,
//             initialCameraPosition: CameraPosition(
//               target: _center,
//               zoom: 11.0,
//             ),
//             markers: _markers,
//             onMapCreated: (GoogleMapController controller) {
//               _controller.complete(controller);
//             },
//           ),
//           Positioned(
//             top: 40.0,
//             left: 10.0,
//             right: 10.0,
//             child: Container(
//               height: 50.0,
//               width: double.infinity,
//               decoration: BoxDecoration(
//                 borderRadius: BorderRadius.circular(10.0),
//                 color: Colors.white,
//               ),
//               child: Row(
//                 children: [
//                   Expanded(
//                     child: TextField(
//                       controller: _addressController,
//                       decoration: InputDecoration(
//                         hintText: 'Enter Address',
//                         border: InputBorder.none,
//                         contentPadding: EdgeInsets.only(left: 15.0, top: 15.0),
//                       ),
//                     ),
//                   ),
//                   IconButton(
//                     icon: Icon(Icons.search),
//                     onPressed: _onSearchButtonPressed,
//                     iconSize: 30.0,
//                   ),
//                   IconButton(
//                     icon: Icon(Icons.directions),
//                     onPressed: _onDirectionsButtonPressed,
//                     iconSize: 30.0,
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
