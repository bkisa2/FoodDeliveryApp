import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:path/path.dart' as path;
import 'package:uuid/uuid.dart';

class SetCarDetailsScreen extends StatefulWidget {
  final String driverId;

  SetCarDetailsScreen({required this.driverId});

  @override
  _SetCarDetailsScreenState createState() => _SetCarDetailsScreenState();
}

class _SetCarDetailsScreenState extends State<SetCarDetailsScreen> {
  final _formKey = GlobalKey<FormState>();
  late String _carNumber;
  late String _hourlyRate;
  late String _carModel;
  late String _licenseNumber;
  File? _imageFile;
  String? _imageUrl;

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      try {
        // Upload the image to Firebase Storage
        final fileName = path.basename(_imageFile!.path);
        final destination = 'car_images/$fileName';
        final firebase_storage.Reference storageReference =
        firebase_storage.FirebaseStorage.instance.ref(destination);
        await storageReference.putFile(_imageFile!);

        // Get the download URL of the uploaded image
        _imageUrl = await storageReference.getDownloadURL();

        // Generate a unique ID for the car details document
        final carDetailsId = const Uuid().v1();

        // Save car details and image URL to Firebase Firestore
        final driverId = widget.driverId; // Use the driver ID passed from the widget
        final carDetails = {
          'id': carDetailsId,
          'carNumber': _carNumber,
          'hourlyRate': _hourlyRate,
          'carModel': _carModel,
          'licenseNumber': _licenseNumber,
          'imageUrl': _imageUrl,
        };

        await FirebaseFirestore.instance
            .collection('drivers')
            .doc(driverId)
            .collection('carDetails')
            .doc(carDetailsId)
            .set(carDetails);

        // Show a success message to the user
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Car details saved successfully')),
        );

        // Navigate back to the previous screen
        Navigator.pop(context);
      } catch (error) {
        // Handle any errors that occur during the saving process
        print('Error saving car details: $error');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to save car details')),
        );
      }
    }
  }


  final picker = ImagePicker();

  Future<void> pickImage() async {
    final XFile? pickedFile = await picker.pickImage(
      source: ImageSource.gallery,
    );

    if (pickedFile != null) {
      _imageFile = File(pickedFile.path);
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Set Car Details'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter car number';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'Car Number',
                ),
                onSaved: (value) {
                  _carNumber = value!;
                },
              ),
              TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter car model';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'Car Model',
                ),
                onSaved: (value) {
                  _carModel = value!;
                },
              ),
              TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter license number';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'License Number',
                ),
                onSaved: (value) {
                  _licenseNumber = value!;
                },
              ),
              SizedBox(height: 16.0),
              TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter license number';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'One Hour Rate ',
                ),
                onSaved: (value) {
                  _hourlyRate = value!;
                },
              ),
              SizedBox(height: 16.0),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 16.0),
                  SizedBox(height: 16.0),
                  if (_imageFile == null)
                    InkWell(
                      onTap: () {
                        pickImage();
                      },
                      child: const Text('Pick Image'),
                    ),
                  SizedBox(height: 16.0),
                  if (_imageFile != null) ...[
                    Image.file(
                      _imageFile!,
                      width: 200,
                      height: 200,
                    ),
                    SizedBox(height: 16.0),
                  ],
                  ElevatedButton(
                    onPressed: _submitForm,
                    child: Text('Save Car Details'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
