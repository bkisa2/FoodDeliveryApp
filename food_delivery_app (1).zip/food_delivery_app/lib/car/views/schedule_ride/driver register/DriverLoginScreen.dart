import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../../../../global/global.dart';
import '../../../../models/driver.dart';
import '../DriverInfoScreen.dart';
import '../DriverRegistrationForm.dart';

class DriverLoginScreen extends StatefulWidget {
  const DriverLoginScreen({Key? key}) : super(key: key);

  @override
  _DriverLoginScreenState createState() => _DriverLoginScreenState();
}

class _DriverLoginScreenState extends State<DriverLoginScreen> {
  final _formKey = GlobalKey<FormState>();

  late String _phoneNumber;
  late String _password;
  late String _name;

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      // Generate a unique driver ID
      final driverId = const Uuid().v1();

      final driver = Driver(
        name: _name,
        phoneNumber: _phoneNumber,
        password: _password,
        id: driverId,
        carDetailsId: '',
      );
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => DriverInfoScreen(driver: driver),
        ),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              Text(
                'Food On-line',
                style: TextStyle(
                  fontSize: 50,
                  color: Colors.amber,
                  shadows: [
                    BoxShadow(
                      blurRadius: 5,
                      color: Colors.green.shade900,
                      offset: Offset(3, 3),
                    )
                  ],
                ),
              ),
              SizedBox(height: 16.0),

              TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter name';
                  }
                  return null;
                },
                decoration: const InputDecoration(
                  labelText: 'Name',
                ),
                onChanged: (value) {
                  _name = value;
                },
              ),

              TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter phone number';
                  }
                  return null;
                },
                decoration: const InputDecoration(
                  labelText: 'Phone Number',
                ),
                onChanged: (value) {
                  _phoneNumber = value;
                },
              ),
              TextFormField(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter password';
                  }
                  return null;
                },
                decoration: const InputDecoration(
                  labelText: 'Password',
                ),
                onChanged: (value) {
                  _password = value;
                },
              ),
              const SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: _submitForm,
                child: const Text('Login'),
              ),
              ElevatedButton(
                onPressed: () {
                  navigate(context, RegisterDriverScreen());
                },
                child: Text('Register Driver'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
