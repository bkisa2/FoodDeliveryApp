import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/widgets.dart';

import '../../../../models/driver.dart';
import 'EditProfileScreen.dart';
class ProfileInfoScreen extends StatelessWidget {
  final Driver driver;


  const ProfileInfoScreen({required this.driver});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile Info'),
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () {
              // Navigator.push(
              //   context,
              //   MaterialPageRoute(
              //     builder: (context) => EditProfileScreen(driver: driver),
              //   ),
              // );
            },
          ),
        ],
      ),
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Name: ${driver.name}',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 10),
            Text(
              'Phone Number: ${driver.phoneNumber}',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 10),

          ],
        ),
      ),
    );
  }
}
