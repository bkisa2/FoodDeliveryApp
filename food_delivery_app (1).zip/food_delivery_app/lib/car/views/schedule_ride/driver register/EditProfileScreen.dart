// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
//
// import '../../../../models/driver.dart';
//
// class EditProfileScreen extends StatefulWidget {
//   final Driver driver;
//
//   const EditProfileScreen({required this.driver});
//
//   @override
//   _EditProfileScreenState createState() => _EditProfileScreenState();
// }
//
// class _EditProfileScreenState extends State<EditProfileScreen> {
//   final _formKey = GlobalKey<FormState>();
//
//   String? _name;
//   String? _phoneNumber;
//   String? _carModel;
//   String? _carNumber;
//   String? _licenseNumber;
//
//   @override
//   void initState() {
//     super.initState();
//     _name = widget.driver.name;
//     _phoneNumber = widget.driver.phoneNumber;
//     _carModel = widget.driver.carModel;
//     _carNumber = widget.driver.carNumber;
//     _licenseNumber = widget.driver.licenseNumber;
//   }
//
//   void _saveChanges() {
//     if (_formKey.currentState!.validate()) {
//       _formKey.currentState!.save();
//       final updatedDriver = widget.driver.copyWith(
//         name: _name!,
//         phoneNumber: _phoneNumber!,
//         carModel: _carModel!,
//         carNumber: _carNumber!,
//         licenseNumber: _licenseNumber!,
//       );
//       // TODO: Save updated driver information to database or backend.
//       Navigator.pop(context);
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Edit Profile Info'),
//       ),
//       body: Form(
//         key: _formKey,
//         child: Container(
//           padding: EdgeInsets.all(16.0),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: <Widget>[
//               TextFormField(
//                 initialValue: _name,
//                 decoration: InputDecoration(
//                   labelText: 'Name',
//                 ),
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Please enter your name';
//                   }
//                   return null;
//                 },
//                 onSaved: (value) => _name = value!,
//               ),
//               SizedBox(height: 10),
//               TextFormField(
//                 initialValue: _phoneNumber,
//                 decoration: InputDecoration(
//                   labelText: 'Phone Number',
//                 ),
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Please enter your phone number';
//                   }
//                   return null;
//                 },
//                 onSaved: (value) => _phoneNumber = value!,
//               ),
//               SizedBox(height: 10),
//               TextFormField(
//                 initialValue: _carModel,
//                 decoration: InputDecoration(
//                   labelText: 'Car Model',
//                 ),
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Please enter your car model';
//                   }
//                   return null;
//                 },
//                 onSaved: (value) => _carModel = value!,
//               ),
//               SizedBox(height: 10),
//               TextFormField(
//                 initialValue: _carNumber,
//                 decoration: InputDecoration(
//                   labelText: 'Car Number',
//                 ),
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Please enter your car number';
//                   }
//                   return null;
//                 },
//                 onSaved: (value) => _carNumber = value!,
//               ),
//               SizedBox(height: 10),
//               TextFormField(
//                 initialValue: _licenseNumber,
//                 decoration: InputDecoration(
//                   labelText: 'License Number',
//                 ),
//
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Please enter your license number';
//                   }
//                   return null;
//                 },
//                 onSaved: (value) => _licenseNumber = value!,
//               ),
//               SizedBox(height: 30),
//               Center(
//                 child: ElevatedButton(
//                   onPressed: _saveChanges,
//                   child: Text('Save Changes'),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
