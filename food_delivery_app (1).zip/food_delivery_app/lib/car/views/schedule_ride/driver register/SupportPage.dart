import 'package:flutter/material.dart';

class DriverSupportPage extends StatelessWidget {
  const DriverSupportPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        title: Text('Support'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Frequently Asked Questions',
              style: Theme.of(context).textTheme.headline6,
            ),
            SizedBox(height: 16),
            ExpansionTile(
              title: Text('How do I start delivering orders?'),
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                      'To start delivering orders, you need to login to the driver dashboard and wait for orders to come in. Once you receive an order, you can accept or reject it.'),
                ),
              ],
            ),
            ExpansionTile(
              title: Text('What if I have trouble finding the delivery address?'),
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                      'If you have trouble finding the delivery address, you can contact the customer for more information. If you still can\'t find the address, please contact our support team.'),
                ),
              ],
            ),
            ExpansionTile(
              title: Text('What if the customer is not available to receive the order?'),
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                      'If the customer is not available to receive the order, you can contact them to arrange a new delivery time. If the customer is still not available, please contact our support team.'),
                ),
              ],
            ),
            SizedBox(height: 32),
            Text(
              'Contact Us',
              style: Theme.of(context).textTheme.headline6,
            ),
            SizedBox(height: 16),
            ListTile(
              leading: Icon(Icons.phone),
              title: Text('Phone'),
              subtitle: Text('123-456-7890'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(Icons.email),
              title: Text('Email'),
              subtitle: Text('support@fooddeliveryapp.com'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(Icons.location_on),
              title: Text('Address'),
              subtitle: Text('123 Main St, Anytown USA'),
              onTap: () {},
            ),
          ],
        ),
      ),
    );
  }
}