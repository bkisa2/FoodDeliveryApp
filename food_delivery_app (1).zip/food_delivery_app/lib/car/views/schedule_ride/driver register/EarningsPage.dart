// import 'package:flutter/material.dart';
//
//
// class EarningsPage extends StatelessWidget {
//   const EarningsPage({Key? key, required this.trips}) : super(key: key);
//
//   final List<Trip> trips;
//
//   @override
//   Widget build(BuildContext context) {
//     double earnings = 0;
//
//     // Calculate the total earnings from all completed trips
//     for (final trip in trips) {
//       if (trip.status == TripStatus.completed) {
//         earnings += trip.cost;
//       }
//     }
//
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Earnings'),
//       ),
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             const Text(
//               'Total earnings',
//               style: TextStyle(
//                 fontSize: 20,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             const SizedBox(height: 8),
//             Text(
//               '\$${earnings.toStringAsFixed(2)}',
//               style: const TextStyle(
//                 fontSize: 32,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }