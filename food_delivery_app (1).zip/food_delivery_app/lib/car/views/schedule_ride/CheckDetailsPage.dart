import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../../../auth/login.dart';
import '../../../pages/food/FavoritesPage.dart';
import '../../../pages/food/HelpPage.dart';
import '../../../pages/food/settingsPage.dart';
import '../../../utils/dimensions.dart';
import '../../../widgets/big_text.dart';
import '../../../widgets/small_text.dart';
import 'DateTimePicker.dart';
import 'RideDetailsPage.dart';
import 'RideHistoryPage.dart';

class CheckDetailsPage extends StatefulWidget {

  final String driverId;

  const CheckDetailsPage({Key? key, required this.driverId}) : super(key: key);

  @override
  State<CheckDetailsPage> createState() => _CheckDetailsPageState();
}

class _CheckDetailsPageState extends State<CheckDetailsPage> {
  late final DocumentSnapshot doc;
  late final driver;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.menu),
          onPressed: () => _scaffoldKey.currentState?.openDrawer(),
        ),
        title: Text(
          'Location',
          style: TextStyle(
            color: Colors.black,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        actions: [
          CircleAvatar(
            backgroundImage: AssetImage('assets/images/dp.jpg'),
            radius: 18,
          ),
          SizedBox(width: 16),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 24),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Welcome!',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
              child: StreamBuilder(
          stream: FirebaseFirestore.instance.collection('drivers').snapshots(),
      builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (!snapshot.hasData) return Container();

        if (snapshot.data!.docs.isEmpty) return Container();

        final data = snapshot.data!.docs;

        return ListView.builder(
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemCount: data.length,
          itemBuilder: (context, index) {
            final driverData = data[index].data(); // access document data
            return InkWell(
              // onTap: () {
              //   Navigator.of(context).push(MaterialPageRoute(
              //     builder: (context) => BookCarScreen(data[index], driverId: '',),
              //   ));
              // },
              child: Container(
                margin: const EdgeInsets.only(bottom: 16),
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          BigText(text: data[index]['name']),
                          SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(
                                Icons.star,
                                color: Colors.amber,
                                size: 18,
                              ),
                              SizedBox(width: 4),
                              Text(
                                '4.5',
                                style: TextStyle(
                                  color: Colors.grey[600],
                                ),
                              ),
                              SizedBox(width: 8),
                              Icon(
                                Icons.phone,
                                color: Colors.grey[600],
                                size: 18,
                              ),
                              SizedBox(width: 4),

                              SmallText(text: data[index]['phoneNumber']),
                            ],
                          ),

                        ],
                      ),
                    ),
                  ],
                ),

              ),
            );
          },
        );
      },
    )
          ),
          Expanded(
              child: StreamBuilder(
                stream: FirebaseFirestore.instance
                    .collection('drivers')
                    .doc(widget.driverId)
                    .collection('carDetails')
                    .snapshots(),
                builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                  if (!snapshot.hasData) return Container();

                  if (snapshot.data!.docs.isEmpty) return Container();

                  final data = snapshot.data!.docs;

                  return ListView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemCount: data.length,
                    itemBuilder: (context, index) {
                      final carDetails = data[index].data(); // access document data
                      return InkWell(
                        onTap: () {
                          Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => BookCarScreen(data[index], driverId: '',),
                          ));
                        },
                        //driverId:widget.driverId,
                        child: Container(
                          //margin: const EdgeInsets.only(bottom: 16),
                           padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 80,
                                height: 80,
                                margin: EdgeInsets.only(right: 16),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(12),
                                  color: Colors.grey[300],
                                  image: DecorationImage(
                                    fit: BoxFit.cover,
                                    image: NetworkImage(data[index]['imageUrl']),
                                  ),
                                ),
                              ),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    BigText(text: data[index]['carNumber']),
                                    SizedBox(height: 8),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.star,
                                          color: Colors.amber,
                                          size: 18,
                                        ),
                                        SizedBox(width: 4),
                                        Text(
                                          data[index]['carModel'],
                                          style: TextStyle(
                                            color: Colors.grey[600],
                                          ),
                                        ),
                                        SizedBox(width: 8),
                                        Icon(
                                          Icons.wallet_rounded,
                                          color: Colors.grey[600],
                                          size: 18,
                                        ),
                                        SizedBox(width: 4),

                                        SmallText(text: data[index]['hourlyRate']),

                                        SizedBox(
                                          height: 8,
                                          width: 30,
                                        ),

                                        ElevatedButton(
                                          onPressed: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>  PickupPage(driverId:widget.driverId,carDetails:  data[index],),
                                              ),
                                            );
                                          },
                                          child: Text('Book Car '),
                                        ),
                                      ],
                                    ),

                                  ],
                                ),
                              ),
                            ],
                          ),

                        ),
                      );
                    },
                  );
                },
              )

          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color:Colors.amber,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.restaurant_menu,
                    size: Dimensions.iconSize24,
                    color: Colors.white,
                  ),
                  SizedBox(height: Dimensions.height10),
                  Text(
                    'Food Delivery App',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: Dimensions.font26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              title: Text('Ride History'),
              leading: Icon(Icons.sort),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => RideHistoryPage()));
              },
            ),
            ListTile(
              title: Text('Favorites'),
              leading: Icon(Icons.favorite),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => FavoritesPage()));

              },
            ),
            ListTile(
              title: Text('Settings'),
              leading: Icon(Icons.settings),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => SettingsPage()));
              },
            ),
            ListTile(
              title: Text('Help'),
              leading: Icon(Icons.help),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => HelpPage()));
              },
            ),
            ListTile(
              title: Text('Logout'),
              leading: Icon(Icons.logout),
              onTap: () async {
                await FirebaseAuth.instance.signOut();
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LoginPage()));
              },
            ),

          ],
        ),
      ),
    );
  }
}