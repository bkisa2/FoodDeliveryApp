import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'DateTimePicker.dart';


class BookCarScreen extends StatelessWidget {
  const BookCarScreen(this.doc, {Key? key, required this.driverId, }) : super(key: key);
  final DocumentSnapshot doc;
  final String driverId;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // Background image
          // Positioned(
          //   top: 0,
          //   left: 0,
          //   right: 0,
          //   child: Container(
          //     height: 200,
          //     decoration: BoxDecoration(
          //       image: DecorationImage(
          //         fit: BoxFit.cover,
          //         image: NetworkImage(doc.get('imageUrl')),
          //       ),
          //     ),
          //   ),
          // ),
          // Icon buttons and title
          // Positioned(
          //   top: 40,
          //   left: 20,
          //   right: 20,
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //     children: [
          //       IconButton(
          //         onPressed: () {
          //           // TODO: Implement back button functionality
          //         },
          //         icon: Icon(
          //           Icons.arrow_back_ios,
          //           color: Colors.white,
          //         ),
          //       ),
          //       IconButton(
          //         onPressed: () {
          //           // TODO: Implement shopping cart button functionality
          //         },
          //         icon: Icon(
          //           Icons.shopping_cart_outlined,
          //           color: Colors.white,
          //         ),
          //       ),
          //     ],
          //   ),
          // ),

          // Content
          Positioned(
            top: 190,
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(

              padding: EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(30),
                ),
              ),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Text('Driver Detail ',
                        style: TextStyle(
                          fontSize: 28,
                          color: Colors.amber,
                        ),
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      doc.get('hourlyRate'),
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Car Model: ${doc.get('carModel')}',
                      style: TextStyle(
                        fontSize: 18,
                        color: Colors.black87,
                      ),
                    ),

                    // FutureBuilder<DocumentSnapshot>(
                    //     future: FirebaseFirestore.instance
                    //         .collection('drivers')
                    //         .doc(driverId)
                    //         .get(),
                    //
                    //     builder: (context, snapshot) {
                    //       if (snapshot.connectionState == ConnectionState.waiting) {
                    //         return CircularProgressIndicator();
                    //       }
                    //       if (snapshot.hasError) {
                    //         return Text('Error: ${snapshot.error}');
                    //       }
                    //       if (!snapshot.hasData) {
                    //         return Text('Driver not found');
                    //       }
                    //       final driverData = snapshot.data!.data() as Map<String, dynamic>?;
                    //       final driverName = driverData?['name'] ?? '';
                    //       final driverPhoneNumber = driverData?['phone'] ?? '';
                    //
                    //       return Column(
                    //         crossAxisAlignment: CrossAxisAlignment.start,
                    //         children: [
                    //           Text(
                    //             'Driver Name: $driverName',
                    //             style: TextStyle(
                    //               fontSize: 18,
                    //               color: Colors.black87,
                    //             ),
                    //           ),
                    //
                    //           SizedBox(height: 10),
                    //           Text(
                    //             'Driver Phone Number: $driverPhoneNumber',
                    //             style: TextStyle(
                    //               fontSize: 18,
                    //               color: Colors.black87,
                    //             ),
                    //           ),
                    //           SizedBox(height: 30),
                    //           ElevatedButton(
                    //             onPressed: () {
                    //               Navigator.push(
                    //                 context,
                    //                 MaterialPageRoute(
                    //                   builder: (context) => PickupPage(driverInfo: doc),
                    //                 ),
                    //               );
                    //             },
                    //             child: Padding(
                    //               padding: EdgeInsets.symmetric(vertical: 16),
                    //               child: Text(
                    //                 'Book Now',
                    //                 style: TextStyle(
                    //                   fontSize: 20,
                    //                   fontWeight: FontWeight.bold,
                    //                 ),
                    //               ),
                    //             ),
                    //             style: ElevatedButton.styleFrom(
                    //               foregroundColor: Colors.white, backgroundColor: Color(0xFF89dad0),
                    //               shape: RoundedRectangleBorder(
                    //                 borderRadius: BorderRadius.circular(30),
                    //               ),
                    //             ),
                    //           ),
                    //         ],
                    //       );
                    //     }
                    // ),
                  ]
              ),
            ),
          )
        ],
      ),
    );
  }
}
