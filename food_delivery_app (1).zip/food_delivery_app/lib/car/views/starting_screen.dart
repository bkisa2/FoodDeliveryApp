import 'package:flutter/material.dart';
import 'package:food_delivery_app/car/views/schedule_ride/DateTimePicker.dart';
import 'package:food_delivery_app/car/views/schedule_ride/HomePage.dart';
import 'package:food_delivery_app/car/views/schedule_ride/schedule_ride.dart';

import '../../widgets/spacer.dart';
import '../global/colors.dart';

class StartingPage extends StatelessWidget {
  const StartingPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            Container(),
            Image.asset(
              'assets/images/car3.jpg',
              height: MediaQuery.of(context).size.height * 0.65,
              alignment: const Alignment(-0.4, 0),
              fit: BoxFit.cover,
            ),
            Positioned(
              bottom: 0,
              height: MediaQuery.of(context).size.height * 0.4,
              width: MediaQuery.of(context).size.width,
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: const BoxDecoration(
                  color: MyColors.white,
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(32),
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(),
                    const Text(
                      'Track your Ride',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: MyColors.black,
                      ),
                    ),
                    const VerticalSpacer(16),
                    Text(
                      'Lorem ipsum is a placeholder text commonly \n '
                      'used to demonstrate the visual form of a',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: MyColors.black.withOpacity(0.8),
                      ),
                    ),
                    const VerticalSpacer(32),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        primary: MyColors.prime,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(32),
                        ),
                        minimumSize:
                            Size(MediaQuery.of(context).size.width, 52),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePageCar(),
                          ),
                        );
                      },
                      child: const Text(
                        'Get Started',
                        style: TextStyle(
                          color: MyColors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    const VerticalSpacer(6),
                    TextButton(
                      child: Text(
                        'SKIP',
                        style: TextStyle(
                          color: MyColors.black.withOpacity(0.75),
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                      onPressed: () {},
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
