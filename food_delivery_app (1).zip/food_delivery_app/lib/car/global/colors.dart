import 'package:flutter/material.dart';

class MyColors {
  static const Color black = Colors.black;
  static const Color white = Colors.white;
  static const Color bg = Color(0xFF89dad0);
  static const Color prime = Colors.amberAccent;
}
