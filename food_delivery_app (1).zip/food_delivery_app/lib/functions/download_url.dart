import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';

Future<String> getImageUrl(File image) async {
  String fileName = DateTime.now().millisecondsSinceEpoch.toString();

  Reference ref = FirebaseStorage.instance.ref().child(fileName);
  TaskSnapshot storageTaskSnapshot = await ref.putFile(image);

  var downloadUrl = await storageTaskSnapshot.ref.getDownloadURL();
  return downloadUrl;
}

Future<String> getVideoUrl(File video) async {
  String fileName = DateTime.now().millisecondsSinceEpoch.toString();

  Reference ref = FirebaseStorage.instance.ref().child(fileName);
  TaskSnapshot storageTaskSnapshot = await ref.putFile(
    video,
    SettableMetadata(contentType: 'video/mp4'),
  );

  var downloadUrl = await storageTaskSnapshot.ref.getDownloadURL();
  return downloadUrl;
}
