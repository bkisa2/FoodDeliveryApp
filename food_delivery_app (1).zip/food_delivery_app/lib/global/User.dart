import 'package:flutter/material.dart';

class UserProvider extends ChangeNotifier {
  late String _userId;

  void updateUser(String userId) {
    _userId = userId;
    notifyListeners();
  }

  String get userId => _userId;
}