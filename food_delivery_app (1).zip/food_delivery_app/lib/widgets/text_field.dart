
import 'package:flutter/material.dart';

import '../car/global/colors.dart';


class MyTextField extends StatelessWidget {
  final String hint;
  final TextEditingController controller;
  final TextInputType type;
  final int lines;
  final bool obscure;
  final bool expanded;
  final IconData? icon;

  const MyTextField({
    Key? key,
    required this.hint,
    required this.controller,
    this.obscure = false,
    this.expanded = false,
    this.type = TextInputType.text,
    this.lines = 1,
    this.icon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final widget = Container(
      decoration: BoxDecoration(
        color: MyColors.black.withOpacity(0.05),
        // color: MyColors.primeLight,
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: TextField(
        textCapitalization: TextCapitalization.sentences,
        obscureText: obscure,
        controller: controller,
        keyboardType: type,
        style: const TextStyle(
          fontSize: 16,
        ),
        maxLines: lines,
        cursorColor: MyColors.bg,
        decoration: InputDecoration(
          suffixIcon: IconButton(
            icon: Icon(icon),
            onPressed: () {},
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.all(14),
          hintText: hint,
          hintStyle: const TextStyle(
            fontSize: 16,
          ),
        ),
      ),
    );

    return expanded ? Expanded(child: widget) : widget;
  }
}
