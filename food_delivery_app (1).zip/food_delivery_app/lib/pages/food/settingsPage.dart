import 'package:flutter/material.dart';

import 'ChangePasswordPage.dart';
import 'ChangeProfilePage.dart';
import 'ChangeUserName.dart';
import 'notificationsPage.dart';


class SettingsPage extends StatefulWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool isDarkModeEnabled = false;

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: isDarkModeEnabled
          ? ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.amber,
        hintColor: Colors.amberAccent,
      )
          : ThemeData(
        brightness: Brightness.light,
        primarySwatch: Colors.amber,
        hintColor: Colors.amberAccent,
      ),
      child: Scaffold(
        appBar: AppBar(
          title: Text('Settings'),
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 16.0),
              Text(
                'Profile Settings',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Divider(height: 24.0),
              ListTile(
                title: Text('Change Profile Picture'),
                leading: Icon(Icons.photo),
                trailing: Icon(Icons.keyboard_arrow_right),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ProfilePage()),
                  );
                },
              ),
              Divider(height: 16.0),
              ListTile(
                title: Text('Change Username'),
                leading: Icon(Icons.person),
                trailing: Icon(Icons.keyboard_arrow_right),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ChangeUserName()),
                  );
                },
              ),
              Divider(height: 16.0),
              ListTile(
                title: Text('Change Password'),
                leading: Icon(Icons.lock),
                trailing: Icon(Icons.keyboard_arrow_right),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ChangePasswordPage()),
                  );
                },
              ),
              SizedBox(height: 32.0),
              Text(
                'App Settings',
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Divider(height: 24.0),
              SwitchListTile(
                title: Text('Dark Mode'),
                secondary: Icon(Icons.dark_mode),
                value: isDarkModeEnabled,
                onChanged: (value) {
                  setState(() {
                    isDarkModeEnabled = value;
                  });
                },
              ),
              Divider(height: 16.0),
              ListTile(
                title: Text('Notifications'),
                leading: Icon(Icons.notifications),
                trailing: Icon(Icons.keyboard_arrow_right),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => NotificationsPage()),
                  );
                },
              ),
              Divider(height: 16.0),
              ListTile(
                title: Text('Language'),
                leading: Icon(Icons.language),
                trailing: Icon(Icons.keyboard_arrow_right),
                onTap: () {

                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

