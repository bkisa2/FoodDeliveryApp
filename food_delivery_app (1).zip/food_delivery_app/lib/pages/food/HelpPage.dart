import 'package:flutter/material.dart';

class HelpPage extends StatelessWidget {
  const HelpPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Help'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Frequently Asked Questions',
              style: Theme.of(context).textTheme.headline6,
            ),
            SizedBox(height: 16),
            ExpansionTile(
              title: Text('How can I place an order?'),
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                      'To place an order, you can simply browse through the available restaurants and menus, add items to your cart, and proceed to checkout.'),
                ),
              ],
            ),
            ExpansionTile(
              title: Text('How long does delivery take?'),
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                      'Delivery time can vary depending on the restaurant and your location. You can check the estimated delivery time during checkout.'),
                ),
              ],
            ),
            ExpansionTile(
              title: Text('Can I cancel an order?'),
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                      'You can cancel an order as long as the restaurant has not started preparing it. Once the restaurant has started preparing the order, cancellation may not be possible.'),
                ),
              ],
            ),
            ExpansionTile(
              title: Text('What if there is a problem with my order?'),
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                      'If there is a problem with your order, such as missing items or incorrect items, please contact our customer support team as soon as possible.'),
                ),
              ],
            ),
            SizedBox(height: 32),
            Text(
              'Contact Us',
              style: Theme.of(context).textTheme.headline6,
            ),
            SizedBox(height: 16),
            ListTile(
              leading: Icon(Icons.phone),
              title: Text('Phone'),
              subtitle: Text('123-456-7890'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(Icons.email),
              title: Text('Email'),
              subtitle: Text('support@fooddeliveryapp.com'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(Icons.location_on),
              title: Text('Address'),
              subtitle: Text('123 Main St, Anytown USA'),
              onTap: () {},
            ),
          ],
        ),
      ),
    );
  }
}
