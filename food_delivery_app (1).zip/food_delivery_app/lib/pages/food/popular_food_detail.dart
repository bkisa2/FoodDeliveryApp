import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/pages/food/cart.dart';
import 'package:uuid/uuid.dart';
import '../../utils/dimensions.dart';
import '../../widgets/app_column.dart';
import '../../widgets/app_icon.dart';
import '../../widgets/big_text.dart';
import '../../widgets/exandable_text_widget.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PopularFoodDetail extends StatelessWidget {
  const PopularFoodDetail(
    this.doc, {
    Key? key,
  }) : super(key: key);

  final DocumentSnapshot doc;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          //background image
          Positioned(
              left: 0,
              right: 0,
              child: Container(
                width: double.maxFinite,
                height: Dimensions.popularFoodImgSize,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        fit: BoxFit.cover,
                        image: NetworkImage(doc.get('imageUrl'))
                    )
                ),
              )),
          //icon widget
          Positioned(
              top: Dimensions.height45,
              left: Dimensions.width20,
              right: Dimensions.width20,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  AppIcon(
                    icon: Icons.arrow_back_ios,
                  ),
                  AppIcon(
                    icon: Icons.shopping_cart_outlined,
                  )
                ],
              )),
          //introduction of food
          Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              top: Dimensions.popularFoodImgSize - 20,
              child: Container(
                padding: EdgeInsets.only(
                    left: Dimensions.width20,
                    right: Dimensions.width20,
                    top: Dimensions.height20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(Dimensions.radius20),
                      topLeft: Radius.circular(Dimensions.radius20)),
                  color: Colors.white,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AppColumn(
                      text: doc.get('name'),
                    ),
                    SizedBox(
                      height: Dimensions.height20,
                    ),
                    BigText(text: "Introduction"),
                    const SingleChildScrollView(
                      child: ExanableTextWidget(
                          text: 'Food is any substance consumed to provide'
                              ' nutritional support for an organism. Food is usually of '
                              ' nutritional support for an organism. Food is usually of '
                              ' nutritional support for an organism. Food is usually of '
                              ' nutritional support for an organism. Food is usually of '
                              ' nutritional support for an organism. Food is usually of '
                              'plant, animal, or fungal origin, and contains essential '
                              'nutrients, such as carbohydrates, fats, proteins, vitamins, '
                              'or minerals.'),
                    )
                  ],
                ),
              )),
          //extanable text widget
        ],
      ),
      bottomNavigationBar: CartBottomNavigationBar(doc),
    );
  }
}

class CartBottomNavigationBar extends StatefulWidget {
  const CartBottomNavigationBar(this.doc, {Key? key}) : super(key: key);

  final DocumentSnapshot doc;

  @override
  _CartBottomNavigationBarState createState() =>
      _CartBottomNavigationBarState();
}

class _CartBottomNavigationBarState extends State<CartBottomNavigationBar> {
  int count = 0;
  double price = 10.0;

  void incrementCount() {
    setState(() {
      count++;
      price += 10.0; // Increase the price by 10
    });
  }

  void decrementCount() {
    setState(() {
      if (count > 0) {
        count--;
        price -= 10.0; // Decrease the price by 10
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: Dimensions.bottomHeightBar,
      padding: EdgeInsets.symmetric(horizontal: Dimensions.width20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            '\$$price', // Display the updated price
            style: TextStyle(
              fontSize: Dimensions.font26,
              fontWeight: FontWeight.bold,
            ),
          ),
          Row(
            children: [
              GestureDetector(
                onTap: decrementCount,
                child: Icon(Icons.remove),
              ),
              SizedBox(width: Dimensions.width20),
              Text(
                count.toString(),
                style: TextStyle(
                  fontSize: Dimensions.font26,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(width: Dimensions.width20),
              GestureDetector(
                onTap: incrementCount,
                child: Icon(Icons.add),
              ),
            ],
          ),
          ElevatedButton(
            onPressed: () {
              addToCart();
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const CartPage()));
            },
            child: Text('Add to Cart'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFF89dad0),
              padding: EdgeInsets.symmetric(
                horizontal: Dimensions.width30,
                vertical: Dimensions.height15,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(Dimensions.radius20),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void addToCart() {
    final id = const Uuid().v1();
    FirebaseFirestore.instance.collection('cart').doc(id).set(
      {
        'id': id,
        'name': widget.doc.get('name'),
        'price': widget.doc.get('price'),
        'imageUrl': widget.doc.get('imageUrl'),
        // 'uid': FirebaseAuth.instance.currentUser!.uid,
        "uid" : FirebaseAuth.instance.currentUser!.uid,
        'quantity': count,
        'created_at': DateTime.now(),
        'updated_at': DateTime.now(),
      },
      SetOptions(merge: true),
    );
  }
}
