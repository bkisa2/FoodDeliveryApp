import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CheckoutPage extends StatefulWidget {
  final List<Map<String, dynamic>> cartItems;
  final double totalPrice;

  const CheckoutPage({
    Key? key,
    required this.cartItems,
    required this.totalPrice,
  }) : super(key: key);

  @override
  _CheckoutPageState createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  String? _deliveryStation;
  String? _orderStation;
  String? _phoneNumber;
  String? _emailAddress;
  String? _paymentMethod;
  String? _orderNotes;
  String? _orderNumber;

  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();
    // Generate unique order number
    _generateOrderNumber();
  }

  void _generateOrderNumber() {
    String userId = _auth.currentUser!.uid;
    String timestamp = DateTime
        .now()
        .millisecondsSinceEpoch
        .toString();
    _orderNumber = userId.substring(0, 5) + timestamp.substring(8);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Checkout'),
        ),
        body: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'Order Summary',
                    style: TextStyle(
                        fontSize: 24.0, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 16.0),
                  Expanded(
                    child: ListView.builder(
                      itemCount: widget.cartItems.length,
                      itemBuilder: (context, index) {
                        final cartItem = widget.cartItems[index];
                        return ListTile(
                          leading: Image.network(
                            cartItem['imageUrl'],
                            width: 50,
                            height: 50,
                          ),
                          title: Text(cartItem['name']),
                          subtitle: Text('\$${cartItem['price']}'),
                          trailing: Text('x${cartItem['quantity']}'),
                        );
                      },
                    ),
                  ),
                  SizedBox(height: 16.0),
                  Text(
                    'Total Price: \$${widget.totalPrice.toStringAsFixed(2)}',
                    style: TextStyle(
                        fontSize: 20.0, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 16.0),
                  TextFormField(
                    decoration: InputDecoration(
                      labelText: 'Delivery Station',
                    ),
                    onChanged: (value) {
                      _deliveryStation = value;
                    },
                  ),
                  SizedBox(height: 8.0),
                  TextFormField(
                    decoration: InputDecoration(
                      labelText: 'Order Station',
                    ),
                    onChanged: (value) {
                      _orderStation = value;
                    },
                  ),
                  SizedBox(height: 8.0),
                  TextFormField(
                    decoration: InputDecoration(
                      labelText: 'Phone Number',
                    ),
                    onChanged: (value) {
                      _phoneNumber = value;
                    },
                  ),
                  SizedBox(height: 8.0),
                  TextFormField(
                    decoration: InputDecoration(
                      labelText: 'Email Address',
                    ),
                    onChanged: (value) {
                      _emailAddress = value;
                    },
                  ),
                  SizedBox(height: 8.0),
                  TextFormField(
                    decoration: InputDecoration(
                      labelText: 'Payment Method',
                    ),
                    onChanged: (value) {
                      _paymentMethod = value;
                    },
                  ),
                  SizedBox(height: 8.0),

                  ElevatedButton(
                    onPressed: () async {
                      // Get the current user's ID
                      String userId = _auth.currentUser!.uid;

                      // Create a new order document
                      await _firestore.collection('orders')
                          .doc(_orderNumber)
                          .set({
                        'orderNumber': _orderNumber,
                        'userId': userId,
                        'deliveryStation': _deliveryStation,
                        'orderStation': _orderStation,
                        'phoneNumber': _phoneNumber,
                        'emailAddress': _emailAddress,
                        'paymentMethod': _paymentMethod,
                        'orderNotes': _orderNotes,
                        'totalPrice': widget.totalPrice,
                        'createdAt': Timestamp.now(),
                      });

                      // Add the items in the cart to the orderItems subcollection
                      for (final cartItem in widget.cartItems) {
                        await _firestore
                            .collection('orders')
                            .doc(_orderNumber)
                            .collection('orderItems')
                            .add({
                          'name': cartItem['name'],
                          'imageUrl': cartItem['imageUrl'],
                          'price': cartItem['price'],
                          'quantity': cartItem['quantity'],
                        });
                      }

                      // // Clear the cart
                      // await _firestore.collection('users').doc(userId).update({
                      //   'cartItems': [],
                      // });

                      // Show success message and navigate to home screen
                      showDialog(
                        context: context,
                        builder: (context) {
                          return AlertDialog(
                            title: Text('Order Placed'),
                            content: Text(
                                'Your order has been placed successfully.'),
                            actions: [
                              TextButton(
                                onPressed: () {
                                  Navigator.of(context).popUntil((
                                      route) => route.isFirst);
                                },
                                child: Text('OK'),
                              ),
                            ],
                          );
                        },
                      );
                    },
                    child: const Text(
                      'Place Order',
                      style: TextStyle(color: Colors.white),
                    ),
                    // color: Colors.blue,
                  ),
                ]
            )
        )
    );

  }
}