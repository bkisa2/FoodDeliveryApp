import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'checkoutPage.dart';

class CartPage extends StatefulWidget {
  const CartPage({Key? key}) : super(key: key);

  @override
  State<CartPage> createState() => _CartPageState();
}
class _CartPageState extends State<CartPage> {
  List<Map<String, dynamic>> _cartItems = []; // Define _cartItems here

  double get _totalPrice {
    double totalPrice = 0.0;
    _cartItems.forEach((item) {
      totalPrice += item['price'] * item['quantity'];
    });
    return totalPrice;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Cart'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Cart Items',
              style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16.0),
            Expanded(
              child: StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection('cart')
                  // .where('uid',
                  //     isEqualTo: FirebaseAuth.instance.currentUser!.uid)
                      .snapshots(),
                  builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                    if (!snapshot.hasData) return Container();

                    if (snapshot.data!.docs.isEmpty) return Container();

                    _cartItems = List<Map<String, dynamic>>.from(snapshot.data!.docs.map((doc) => doc.data())).toList();


                    return ListView.builder(
                      itemCount: _cartItems.length,
                      itemBuilder: (context, index) {
                        final cartItem = _cartItems[index];
                        return ListTile(
                          leading: Image.network(
                            cartItem['imageUrl'],
                            width: 50,
                            height: 50,
                          ),
                          title: Text(cartItem['name']),
                          subtitle: Text('\$${cartItem['price']}'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: Icon(Icons.remove),
                                onPressed: () {
                                  setState(() {
                                    if (cartItem['quantity'] > 1) {
                                      cartItem['quantity'] -= 1;
                                    } else {
                                      _cartItems.removeAt(index);
                                    }
                                  });
                                },
                              ),
                              Text(cartItem['quantity'].toString()),
                              IconButton(
                                icon: Icon(Icons.add),
                                onPressed: () {
                                  setState(() {
                                    cartItem['quantity'] += 1;
                                  });
                                },
                              ),
                            ],
                          ),
                        );
                      },
                    );
                  }),
            ),
            SizedBox(height: 16.0),
            Text(
              'Total Price: \$${_totalPrice.toStringAsFixed(2)}',
              style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Color(0xFF89dad0)),
              ),
              onPressed: () {
                // Navigate to checkout page
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CheckoutPage(cartItems: _cartItems, totalPrice: _totalPrice)),
                );
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Text(
                  'Checkout',
                  style: TextStyle(fontSize: 20.0),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
