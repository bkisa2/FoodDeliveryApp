// // all_shops_screen.dart
//
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';
// import 'package:food_delivery_app/models/shop.dart';
//
// class AllShopsScreen extends StatefulWidget {
//   const AllShopsScreen({Key? key}) : super(key: key);
//
//   @override
//   _AllShopsScreenState createState() => _AllShopsScreenState();
// }
//
// class _AllShopsScreenState extends State<AllShopsScreen> {
//   late Stream<QuerySnapshot> _shopsStream;
//
//   @override
//   void initState() {
//     super.initState();
//     _shopsStream = FirebaseFirestore.instance.collection('shops').snapshots();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('All Shops'),
//       ),
//       body: StreamBuilder<QuerySnapshot>(
//         stream: _shopsStream,
//         builder: (context, snapshot) {
//           if (snapshot.hasData) {
//             final shopDocs = snapshot.data!.docs;
//             final shops = shopDocs.map((doc) => Shop.fromDocument(doc)).toList();
//             return ListView.builder(
//               itemCount: shops.length,
//               itemBuilder: (context, index) {
//                 final shop = shops[index];
//                 return ListTile(
//                   title: Text(shop.shopName),
//                   subtitle: Text(shop.address),
//                   trailing: Icon(Icons.arrow_forward),
//                   onTap: () {
//                     // Navigate to shop details screen
//                   },
//                 );
//               },
//             );
//           } else if (snapshot.hasError) {
//             return Center(child: Text('Error loading shops'));
//           } else {
//             return Center(child: CircularProgressIndicator());
//           }
//         },
//       ),
//     );
//   }
// }