import 'package:flutter/material.dart';

class OrderDetailPage extends StatelessWidget {
  final String orderNumber;
  final String deliveryStation;
  final String orderStation;
  final String phoneNumber;
  final String emailAddress;
  final String paymentMethod;
  final String orderNotes;
  final double totalPrice;

  const OrderDetailPage({
    Key? key,
    required this.orderNumber,
    required this.deliveryStation,
    required this.orderStation,
    required this.phoneNumber,
    required this.emailAddress,
    required this.paymentMethod,
    required this.orderNotes,
    required this.totalPrice,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Order Detail'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Order Number: $orderNumber',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16.0),
            Text(
              'Delivery Station: $deliveryStation',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              'Order Station: $orderStation',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              'Phone Number: $phoneNumber',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              'Email Address: $emailAddress',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              'Payment Method: $paymentMethod',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              'Order Notes: $orderNotes',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 16.0),
            Text(
              'Total Price: \$${totalPrice.toStringAsFixed(2)}',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
