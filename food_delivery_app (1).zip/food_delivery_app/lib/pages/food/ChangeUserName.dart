import 'package:flutter/material.dart';

class ChangeUserName extends StatefulWidget {
  @override
  _ChangeUserNameState createState() => _ChangeUserNameState();
}

class _ChangeUserNameState extends State<ChangeUserName> {
  String _username = 'John Doe';
  TextEditingController _textEditingController =
  TextEditingController(text: 'John Doe');

  @override
  void dispose() {
    _textEditingController.dispose();
    super.dispose();
  }

  void _updateUsername(String value) {
    setState(() {
      _username = value;
    });
  }

  void _saveUsername() {
    setState(() {
      _username = _textEditingController.text;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Change Username'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Username',
              style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _textEditingController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Enter your username',
                    ),
                    onChanged: (value) {
                      _updateUsername(value);
                    },
                  ),
                ),
                SizedBox(width: 16.0),
                ElevatedButton(
                  onPressed: _saveUsername,
                  child: Text('Save'),
                ),
              ],
            ),
            SizedBox(height: 16.0),
            Text(
              'Your new username is: $_username',
              style: TextStyle(fontSize: 16.0),
            ),
          ],
        ),
      ),
    );
  }
}