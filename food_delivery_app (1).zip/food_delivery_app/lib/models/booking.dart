class Booking {
  final String driverName;
  final String carMakeAndModel;
  final String pickupLocation;
  final String pickupTime;


  Booking({
    required this.driverName,
    required this.carMakeAndModel,
    required this.pickupLocation,
    required this.pickupTime,
  });
}