class RideSchedule {
  final DateTime pickupTime;
  // final DateTime pickupDate;
  final int phoneNumber;
  final String userName;
  final String stationName;
  final String destination;


  RideSchedule( {
    required this.pickupTime,
    // required this.pickupDate,
    required this.stationName,
    required this.destination,
    required this.phoneNumber,
    required this.userName,
  });
}
