import 'package:cloud_firestore/cloud_firestore.dart';

import '../shop/Product/widgets/product.dart';

class Shop {
  final String id;
  final String ownerName;
  final String shopName;
  final String address;
  final String phoneNumber;
  final List<Product>? products;

  Shop({
    required this.id,
    required this.ownerName,
    required this.shopName,
    required this.address,
    required this.phoneNumber,
    this.products,
  });

  factory Shop.fromSnapshot(DocumentSnapshot snapshot) {
    Map<String, dynamic> data = snapshot.data() as Map<String, dynamic>;
    List<dynamic> productsData = data['products'] ?? [];

    final List<Product>? products = productsData.map((productData) => Product.fromMap(productData)).cast<Product>().toList();


    return Shop(
      id: snapshot.id,
      ownerName: data['ownerName'],
      shopName: data['shopName'],
      address: data['address'],
      phoneNumber: data['phoneNumber'],
      products: products,

    );
  }

  Map<String, dynamic> toMap() {
    final List productsData =
        products?.map((product) => product.toMap()).toList() ?? [];

    return {
      'id': id,
      'ownerName': ownerName,
      'shopName': shopName,
      'address': address,
      'phoneNumber': phoneNumber,
      'products': productsData,
    };
  }
}
