
class Trip {
  final String start;
  final String end;
  final double fare;

  Trip({
    required this.start,
    required this.end,
    required this.fare,
  });
}

class Driver {
  final String id;
  final String name;
  final String phoneNumber;
  final String password;
  final String carDetailsId;

  Driver({
    required this.id,
    required this.name,
    required this.phoneNumber,
    required this.password,
    required this.carDetailsId,
    // this.tripHistory = const [],
     // provide default value
  });
  String get getId => id;
  // Map<String, dynamic> toJson() {
  //   List<Map<String, dynamic>> tripHistoryData = tripHistory.map((trip) {
  //     return {
  //       'start': trip.start,
  //       'end': trip.end,
  //       'fare': trip.fare,
  //     };
  //   }).toList();

  //   return {
  //     'name': name,
  //     'phoneNumber': phoneNumber,
  //     'carModel': carModel,
  //     'carNumber': carNumber,
  //     'licenseNumber': licenseNumber,
  //     'password': password,
  //     'confirmPassword': confirmPassword,
  //     'tripHistory': tripHistoryData,
  //   };
  // }
  //
  // factory Driver.fromJson(String jsonString) {
  //   final Map<String, dynamic> json = jsonDecode(jsonString);
  //   return Driver(
  //     name: json['name'],
  //     phoneNumber: json['phoneNumber'],
  //     carModel: json['carModel'],
  //     carNumber: json['carNumber'],
  //     licenseNumber: json['licenseNumber'],
  //     password: json['password'],
  //     confirmPassword: json['confirmPassword'],
  //     imageUrl: json['imageUrl'],
  //     hourlyRate: json['hourlyRate'],
  //
  //   );
  // }
  //
  // Driver copyWith({
  //   String? name,
  //   String? phoneNumber,
  //   String? carModel,
  //   String? carNumber,
  //   String? licenseNumber,
  //   String? imageUrl,
  //
  // }) {
  //   return Driver(
  //     name: name ?? this.name,
  //     phoneNumber: phoneNumber ?? this.phoneNumber,
  //     carModel: carModel ?? this.carModel,
  //     carNumber: carNumber ?? this.carNumber,
  //     licenseNumber: licenseNumber ?? this.licenseNumber,
  //     password: password ?? this.password,
  //     confirmPassword: confirmPassword ?? this.confirmPassword,
  //     hourlyRate: hourlyRate,
  //     tripHistory: tripHistory,
  //     imageUrl: imageUrl?? this.imageUrl,
  //   );
  // }
  //
  // static Driver fromSnapshot(DocumentSnapshot snapshot) {
  //   Map<String, dynamic> data = snapshot.data() as Map<String, dynamic>;
  //   List<Trip> tripHistory = [];
  //   if (data['tripHistory'] != null) {
  //     List<dynamic> tripHistoryData = data['tripHistory'];
  //     tripHistory = tripHistoryData.map((data) {
  //       return Trip(
  //         start: data['start'] ?? '',
  //         end: data['end'] ?? '',
  //         fare: data['fare'] ?? 0,
  //       );
  //     }).toList();
  //   }
  //   return Driver(
  //     name: data['name'] ?? '',
  //     phoneNumber: data['phoneNumber'] ?? '',
  //     carModel: data['carModel'] ?? '',
  //     carNumber: data['carNumber'] ?? '',
  //     licenseNumber: data['licenseNumber'] ?? '',
  //     password: data['password'] ?? '',
  //     confirmPassword: data['confirmPassword'] ?? '',
  //     tripHistory: tripHistory,
  //     imageUrl:data['imageUrl']??'',
  //       hourlyRate:data['hourlyRate']??'',
  //
  //   );
  // }

}